%SAMPLES WITH LABLE=1 ARE CLASSIFIED AS RED
function displayRBPoints(dataset, labels, newFigure)
redSet=dataset(logical(labels==1),:);
blueSet=dataset(logical(labels~=1),:);
if newFigure
    figure;
end
scat1=scatter(redSet(:,1),redSet(:,2),'filled');
scat1.MarkerFaceColor='r';
if newFigure
    hold
end
scat2=scatter(blueSet(:,1),blueSet(:,2),'filled');
scat2.MarkerFaceColor='b';
end