%SAMPLES WITH LABLE=1 ARE CLASSIFIED AS RED
function displayRBPoints(dataset, labels, newFigure, platform)
redSet=dataset(logical(labels==1),:);
blueSet=dataset(logical(labels~=1),:);
if newFigure
    figure;
end
if strcmp(platform,'matlab')
  scat1=scatter(redSet(:,1),redSet(:,2),'filled');
  scat1.MarkerFaceColor='r';
end
if strcmp(platform,'octave')
  scatter(redSet(:,1),redSet(:,2),30,'r','filled')
end 
if newFigure
    hold
end
if strcmp(platform,'matlab')
  scat2=scatter(blueSet(:,1),blueSet(:,2),'filled');
  scat2.MarkerFaceColor='b';
 end
 if strcmp(platform,'octave')
  scatter(blueSet(:,1),blueSet(:,2),30,'b','filled')
end 
end