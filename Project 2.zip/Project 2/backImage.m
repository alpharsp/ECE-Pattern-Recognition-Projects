function img = backImage(DataSet,W,Wo)
        %Boundaries of Image
            minx=floor(min(DataSet(:,1)));maxx=ceil(max(DataSet(:,1)));
            miny=floor(min(DataSet(:,2)));maxy=ceil(max(DataSet(:,2)));
        %Color everyPixel
            xAxis=minx:1:maxx;
            yAxis=(miny:1:maxy)';
            xyMatrix(:,:,1)=ones(maxy-miny+1,1)*xAxis;
            xyMatrix(:,:,2)=yAxis*ones(1,maxx-minx+1);
            %g and z correspong to the discriminant function and distance
            %from the decision hyperplane for each of the pixels in the
            %quantized space of the samples
            g=(xyMatrix(:,:,1)*W(1))+(xyMatrix(:,:,2)*W(2))+Wo;
            z=g/sqrt(sum(W.^2));
            %min z correspongs to the farthest point in blue space
            %max z corresponds to the farthest point in red space
            %The background will be red on the redsize and blue on the blue
            %side with a max intensity of 128/255
            redBack=z>=1; %Further than margin
            redBack=uint8(128*(redBack.*z)/max(max(z)));
            blueBack=z<=-1; %Further than Margin
            blueBack=uint8(128*(blueBack.*z)/min(min(z)));
            greenBack=uint8(zeros(size(redBack)));
            BackColor(:,:,1)=redBack;
            BackColor(:,:,2)=greenBack;
            BackColor(:,:,3)=blueBack;
            img=BackColor;
end