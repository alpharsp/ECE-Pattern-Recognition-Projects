function img = backImage(DataSet,supportVectors,SValpha,SVlabels,Wo,KernelOptions,KernelWeights,rbf_sigma)
        %Boundaries of Image
            minx=floor(min(DataSet(:,1)));maxx=ceil(max(DataSet(:,1)));
            miny=floor(min(DataSet(:,2)));maxy=ceil(max(DataSet(:,2)));
        %Color everyPixel
            xAxis=minx:1:maxx;
            yAxis=(miny:1:maxy)';
            rows=maxy-miny+1;
            cols=maxx-minx+1;
            xyMatrix(:,:,1)=ones(rows,1)*xAxis;
            xyMatrix(:,:,2)=yAxis*ones(1,cols);
            %Ordered list of all the pixels p11,p12,...,p1maxX,p21,p22,...pmaxYmaxX
            pixels=[];
            for i=1:rows
              rowElements=zeros(2,cols);
              rowElements(1,:)=xyMatrix(i,:,1);
              rowElements(2,:)=xyMatrix(i,:,2);
              pixels=[pixels;rowElements'];
            end
            %this is a kernel where the rows are the support vectors and the
            %columns are the points to evaluate under the discriminant function g(x)
            %this needs to be done this way because kernels that are not dot functions$could've been used
            kernel=getKernel(supportVectors,pixels,KernelOptions,KernelWeights,rbf_sigma);
            g=(SValpha.*SVlabels)'*kernel; %this is equivalent to W'*X in the discriminant function
            g=g.+Wo;  %this is equivalent to W'*X+Wo in the discriminant function
            %put back g(x) in its matrix form so for each coordinate we know whats the value g(x)
            counter=1;
            gmatrix=zeros(rows,cols);
            for i=1:rows
              rowElements=g(1,counter:1:counter+cols-1);
              gmatrix(i,:)=rowElements;
              counter=counter+cols;
            end
            %Dark red on red margin
                redBack1=gmatrix>0;
                redBack1=uint8(60.*redBack1);
                blueBack1=gmatrix<0;
                blueBack1=uint8(60.*blueBack1);
            %Further than the Margin
                redBack2=gmatrix>=1; 
                redBack2=uint8(180*(redBack2.*gmatrix)/max(max(gmatrix)));
                blueBack2=gmatrix<=-1; 
                blueBack2=uint8(180*(blueBack2.*gmatrix)/min(min(gmatrix)));
            %Add Reds/Blues
                redBack=redBack1.+redBack2;
                blueBack=blueBack1.+blueBack2;
            %Green Decision Line
                greenBack1=gmatrix>=-0.1; 
                greenBack2=gmatrix<=0.1; 
                greenBack=zeros(size(blueBack));%uint8(and(greenBack1,greenBack2)*255);
            %Not as bright Margin line
                greenBack1=abs(gmatrix)>=0.95; 
                greenBack2=abs(gmatrix)<=1.05; 
                greenBack=greenBack+uint8(and(greenBack1,greenBack2)*125);
            %Cap at 255
            redBack=((redBack>255).*255).+((redBack<=255).*redBack);
            blueBack=((blueBack>255).*255).+((blueBack<=255).*blueBack);
            greenBack=((greenBack>255).*255).+((greenBack<=255).*greenBack);
            BackColor(:,:,1)=redBack;
            BackColor(:,:,2)=greenBack;
            BackColor(:,:,3)=blueBack;
            img=BackColor;
end