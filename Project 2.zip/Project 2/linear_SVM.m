%THIS FUNCTION IS USED TO DETERMINE THE PARAMETERS OF A DECISION HYPERPLANE
%OF A BINARY CLASSIFIER GIVEN A 2 CLASS LABELED DATASET USING SVM (SUPPORT
%VECTOR MACHINE) WHEN THE DATA IS LINEARLY SEPARABLE.
%THE KERNEL USED IS THE BASIC DOT PRODUCT
%----------------------------------------------------
%INPUTS:
    %DataSet, training samples of the SVM with N Row samples and M column
    %features
    
    %labels, labels for the dataset where class1=>label=1, label=-1
    %elsewhere, the index correspond to th DataSet samples
    
    %minAlpha represents the min value of alpha to be considered a support
    %vector, numbers seem to be really close to 0 but not 0 when they are
    %not support vectors
%OUTPUTS:
    %W and Wo parameters of the perceptron
    %Index, is the list of indexes of the support vectors among the data
    %samples in the DataSet
function [W,Wo,Indexes] = linear_SVM(DataSet, labels, minAlpha)
    %Paramters for the quadratic programming
        H=DataSet*DataSet'.*(labels'*labels);
        N=size(DataSet,1);
        f=-ones(N,1);
        A=-eye(N);
        a=zeros(N,1);
        B=[labels;zeros(N-1,N)];
        b=zeros(N,1);
    %Quadratic programmin returns the lagrange multipliers where support
    %vectors have alpha>0, 0 otherwise
        alpha=quadprog(H+eye(N)*0.001,f,A,a,B,b);
    %Index of support vector machine
        Indexes=find(alpha>minAlpha);
    %Calculate perceptron parameters
    W=(alpha.*labels')'*DataSet;
        %Index of the largest support vector
        index=find(alpha>=max(alpha));
    Wo=1/labels(index(1))-(W*DataSet(index(1),:)');
end