%%This is my personal Function created to extract data from datasets
%%If needed it will be improved with the time to fit on most data
%%structures, right now it can detect data and labels for space and comma 
%%separators as long as the user knows which column on the data belongs to
%%the labels. The user doesnt need to know the size of the data.
%%------------------------------------------------------------------------
function [Data,labels] = readDataset(fileLocation, labelColumn, platform)
    %OPEN FILE AS A STRING
    fileLocation=char(fileLocation); %Converts from string to char vector
    text=fileread(fileLocation);
    %SET SEPARATIONS AS COMMAS
        spaces=size(strfind(text,'  '));
        spaces=spaces(1,2);
        while (spaces>0)
            if platform=='matlab'
              text=replace(text,'  ',' ');
            end
            if platform=='octave'
              text= strrep(text,'  ',' ');
            end
            spaces=size(strfind(text,'  '));
            spaces=spaces(1,2);
        end
        if platform=='matlab'
          text =replace(text,' ',',');
        end
        if platform=='octave'
          text = strrep(text,' ',',');
        end
    %DEFINE LINE SEPARATIONS AS '|'
        if platform=='matlab'
          text=replace(text,char(10),'|');
          text =replace(text,char(13),'|');
        end
        if platform=='octave'
          text= strrep(text,char(10),'|');
          text = strrep(text,char(13),'|');
        end
        ds=size(strfind(text,'||'));
        ds=ds(1,2);
        while (ds>0)
            if platform=='matlab'
              text=replace(text,'||','|');
            end
            if platform=='octave'
              text= strrep(text,'||','|');
            end
            ds=size(strfind(text,'||'));
            ds=ds(1,2);
        end
    %ELIMINATE UNNECESARY COMMAS AND LINE SEPARATORS
        if platform=='matlab'
          text=replace(text,'|,','|');
          text=replace(text,',|','|');
        end
        if platform=='octave'
          text= strrep(text,'|,','|');
          text= strrep(text,',|','|');
        end
        while((text(1:1)==',') || (text(1:1)=='|'))
            text=text(2:length(text));
        end
        while((text(length(text):length(text))==',') || (text(length(text):length(text))=='|'))
            text=text(1:length(text)-1);
        end
    %GET NUMBER OF ROWS AND NUMBER OF COLUMNS
        if platform=='matlab'
          rows=length(text)-length(replace(text,'|',''))+1;
        end
        if platform=='octave'
          rows=length(text)-length( strrep(text,'|',''))+1;
        end
        i=1;
        cols=0;
        while (text(i:i) ~= '|')
            i=i+1;
            if (text(i:i)==',')
                cols=cols+1;
            end
        end
        cols=cols+1;
    %CREATE DATA MATRIX AND LABELS TO RETURN
        str1=strsplit(text,"|")';
        Data=zeros(rows,cols-1);
        for i=1:rows
            strTemp=char(str1(i));
            currentCols=strsplit(strTemp,',');
            labels(i)=currentCols(labelColumn);
            colCounter=1;
            for j=1:cols
                if j~=labelColumn
                    currentCols(j);
                    Data(i,colCounter)=str2num(cell2mat(currentCols(j)));
                    colCounter=colCounter+1;
                end
            end
        end
        %Data=cell2mat(Data);
        labels=labels';
end