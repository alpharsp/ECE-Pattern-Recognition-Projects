%THIS IS THE SVM FOR 1 CLASS WHICH MEANS IT WILL TELL US WETHER AN ELEMENT
%ON THE TEST DATASET BELONGS TO CLASS 1 OR NOT, IT CAN BE USED AS A LAYER
%OF A MULTICLASS CLASSIFICATION ALGORITHM OR DIRECTLY AS A 2 CLASS
%CLASSIFIER.
%-------------------------------------------------------------------------
%PLATFORM: the options are eoither octave or matlab
  platform='octave';
%INPUTS:
    %SAMPLES:
    	%IMAGE ADRESS
          ImageAddress='RBImages/Image0.png';
          %ImageAddress='RBImages/Image1.bmp';
          %ImageAddress='RBImages/Image2.bmp';
          ImageAddress='RBImages/Circular.png';
          %ImageAddress='RBImages/Circular2.png';
       %SAVE IMAGE DATA INTO txt dataset
           %exportRBData(ImageAddress);
       %GET DATASET FROM IMAGE
          [RD,BD]=RBImageToDataset(ImageAddress);
          DataSet=[RD;BD];
          labels=[ones(size(RD,1),1);-1*ones(size(BD,1),1)];
       %SAVE IMAGE DATA INTO txt dataset
          %exportRBData('RBImages/Image0.png');
       %GET DATASET FROM DATA
          %Use same algorithm as bayes
       %READ DATASET
          fileLoc='DataSets\bezdekIris.data';
          [DataSet,labels] = readDataset(fileLoc,5,platform);
          %The first Class will be class 1 and the rest will be class 2
          c1=char(labels(1,1));
          labels=char(labels);
          labels0=zeros(size(labels,1),1);
          for i=1:size(labels)
            labels0(i,1)=strcmp(strtrim(labels(i,:)),strtrim(c1));
          end
          labels=(labels0.*2).-1;
DataSet=DataSet(:,[1,2]);
%DATA AND LABELS MUST BE IN FORM OF COLUMN VECTORS
%-------------------------------------------------------------------------
if size(DataSet,1)>0
  %SVM THE SVM ITSELF IS MULTY DIMENSIONAL
  %Parameters for the SVM
    c=100;
    rbf_sigma=10; %it will only be used if rbf is selected as kernel
    minAlpha=0.00000001; %min value of lagrange multiplier to consider a vector as support vector
  %Generate kernel
    KernelOptions='-dot-rbf-poly2-poly3';
    Kweights='-1-1-0-0';
    %large kernel with all data
    kernel=getKernel(DataSet,DataSet,KernelOptions,Kweights,rbf_sigma);
  %obtain wo Bias using quadratic programming
    [wo,Indexes,alpha]=nonlinear_SVM(labels,kernel,c,minAlpha,platform);
  %get some components for the classification using the lagrange multipliers>0 (alpha)
    supportVectors=DataSet(Indexes,:);
    totalVectors=(size(supportVectors,1));
    SValpha=alpha(Indexes,1);
    SVlabels=labels(Indexes,1);
  %classify points
    %kernel with Support vectors against all data
    skernel=getKernel(supportVectors,DataSet,KernelOptions,Kweights,rbf_sigma);
    g=(SValpha.*SVlabels)'*skernel; %this is equivalent to W'*X in the discriminant function
    g=(g.+wo)';
  %get Incorrectly Classified points
    incorrectIndex=find(((g.*labels)<0));
    incorrect=DataSet(find(incorrectIndex));
  %-------------------------------------------------------------------------
  %PRINT KERNEL
      img=uint8(255.*kernel.*(labels*labels')./max(max(kernel)));
      figure;
      imshow(img);
  %2D PLOTS
    %Dimensions to plot:
      d1=1;
      d2=2;
      D2DataSet=DataSet(:,[d1,d2]);
    %create backImage
      BackColor=backImage(D2DataSet,supportVectors(:,[d1,d2]),SValpha,SVlabels,wo,KernelOptions,Kweights,rbf_sigma);
      figure
      imshow(BackColor)
      hold
      %Translate points so the min x an y match the 0,0 of the image
      imgDataSet=D2DataSet;
      imgDataSet(:,1)=imgDataSet(:,1)-min(imgDataSet(:,1));
      imgDataSet(:,2)=imgDataSet(:,2)-min(imgDataSet(:,2));
      displayRBPoints(imgDataSet,labels,false,platform);
      %Support Vectors
      scatter(imgDataSet(Indexes,1),imgDataSet(Indexes,2),200,'s');
  axis ij;
else
    disp('Image Data not found or read Incorrectly');
end
