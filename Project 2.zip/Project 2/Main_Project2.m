%THIS IS THE SVM FOR 1 CLASS WHICH MEANS IT WILL TELL US WETHER AN ELEMENT
%ON THE TEST DATASET BELONGS TO CLASS 1 OR NOT, IT CAN BE USED AS A LAYER
%OF A MULTICLASS CLASSIFICATION ALGORITHM OR DIRECTLY AS A 2 CLASS
%CLASSIFIER.
%-------------------------------------------------------------------------
%INPUTS:
    %SAMPLES:
    	%SYNTHETIC DATASETS
        %IMAGE0 (Linearly Separable for example)
        [RD0,BD0]=RBImageToDataset('RBImages/Image0.png');
        Samp0=[RD0;BD0];
        labels0=[ones(size(RD0,1),1);-1*ones(size(BD0,1),1)];
        %IMAGE1
        [RD1,BD1]=RBImageToDataset('RBImages/Image2.png');
        Samp1=[RD1;BD1];
        labels1=[ones(size(RD1,1),1);-1*ones(size(BD1,1),1)];
        %IMAGE2
        [RD2,BD2]=RBImageToDataset('RBImages/Image1.png');
        Samp2=[RD2;BD2];
        labels2=[ones(size(RD2,1),1);-1*ones(size(BD2,1),1)];
        %IMAGE3
        [RD3,BD3]=RBImageToDataset('RBImages/Circular.png');
        Samp3=[RD3;BD3];
        labels3=[ones(size(RD3,1),1);-1*ones(size(BD3,1),1)];
%-------------------------------------------------------------------------
%We will consider Red Data as Class1 and Blue Data as Class 2
%hence the labels for red are 1 and -1 for the blue in the SVM
%DATA TO PLAY WITH
%c=3;
%minAlpha=0.0001;
%Kernels='-dot-rbf';
%Kweights='-4.7-1';
%DataSet=Samp2;
%y=labels2';
%-
c=1;
minAlpha=0.0001;
Kernels='-dot-rbf-poly2-poly3';
Kweights='-1-0-0-0';
DataSet=Samp1;
y=labels1';
[w,wo,Indexes,index]=nonlinear_SVM(DataSet,y,c,Kernels,Kweights,minAlpha,true);
%-------------------------------------------------------------------------
%PLOTS
    %SYNTHETIC
        %Reverse Y axis since Images origin is the topleft corner
        
            %Show Support Vectors
            
        bias=-wo/w(2);
        slope=-1/(w(2)/w(1)); %the slope of the line is the inverse of the w vector
        
        %BackImage
        BackColor=backImage(DataSet,w,wo);

figure
imshow(BackColor)
hold
%Translate points so the min x an y match the 0,0 of the image
imgDataSet=DataSet;
imgDataSet(:,1)=imgDataSet(:,1)-min(imgDataSet(:,1));
imgDataSet(:,2)=imgDataSet(:,2)-min(imgDataSet(:,2));
displayRBPoints(imgDataSet,y,false)
%Support Vectors
scatter(imgDataSet(Indexes,1),imgDataSet(Indexes,2),100,'s')
%Hyperplane
refline(slope,bias-min(imgDataSet(:,2)))
axis([0,1800,0,700])
axis ij;

