function exportRBData(imageLocation)
  [RD0,BD0]=RBImageToDataset(imageLocation);
  [file,path]=uiputfile('.txt','Save Dataset','Red_Blue_Dataset.txt');
  fileLocation=[path,file];
  fid=fopen(fileLocation,'w');
  fprintf(fid,'%.4f   %.4f   red\r\n',RD0);
  fprintf(fid,'%.4f   %.4f   blue\r\n',BD0);
  fclose(fid);
end