function [Wo_avg,Indexes,alpha] = nonlinear_SVM(labels, kernel, c,  minAlpha, platform)
    %Paramters for the quadratic programming
        N=size(labels,1);
        H=kernel.*(labels*labels');
        %Rest of parameters of Quadratic Programming
        f=-ones(N,1);
        %Inequality constraints
          A=eye(N);
          lb=zeros(N,1); 
          ub=c*ones(N,1); 
          b=ub;
        %Equality Constraints
        Aeq=[labels';zeros(N-1,N)];
        beq=zeros(N,1);
        %TEST
    %Quadratic programmin returns the lagrange multipliers where support
    %vectors have alpha>0, 0 otherwise
        if strcmp(platform,'matlab')
          alpha=quadprog(H+eye(N)*0.001,f,A,b,Aeq,beq,lb,ub);
        end
         if strcmp(platform,'octave')
          alpha=qp([],H+eye(N)*0.001,f,Aeq,beq,lb,ub);
        end
    %Index of support vectors
        Indexes=find(alpha>minAlpha);
    %Calculate perceptron parameters
        %Wo as the mean of the wo of all the support vectors
        Wo_avg=0;
        totSV=size(Indexes,1);
        for i=1:totSV
          index=Indexes(i);
          %since g(x)=y*(w'*x)+wo
          %and when using a non dot kernel  we substitute x'*x by a kernel
          Wo=1/labels(index,1)-sum(alpha.*labels.*kernel(:,index));
          Wo_avg=Wo_avg+Wo;
        end
        Wo_avg=Wo_avg/totSV;
end