%THIS FUNCTION IS USED TO DETERMINE THE PARAMETERS OF A DECISION HYPERPLANE
%OF A BINARY CLASSIFIER GIVEN A 2 CLASS LABELED DATASET USING SVM (SUPPORT
%VECTOR MACHINE) WHEN THE DATA IS NON LINEARLY SEPARABLE, BY MINIMIZING THE 
%CLASSIFICATION ERROR.
%----------------------------------------------------
%INPUTS:
    %DataSet, training samples of the SVM with N Row samples and M column
    %features
    
    %labels, labels for the dataset where class1=>label=1, label=-1
    %elsewhere, the index correspond to th DataSet samples
    
    %c, constant used to adjust the sensitivity of the classification
    %error, small values of c create a more generic classifier that
    %increase the margin. large c values create a more rigid classifier
    %that tries to minimize the classification error. you play with c.
    %It must be larger than 0
    
    %kernels, is the character array with all kernels that want to be 
    %combined for the SVM. The string will just list them sequencially, 
    %you can select only 1 if desired or as many different ones as you want
    %The kernels are equally balanced hence all have the same level of
    %These are the options:
        %'-dot'     (Inner Product Kernel)
        %'-rbf'     (Radial Base Function Kernel)
        %'-poly2'   (Quadratic Polynomial)
        %'-poly3'   (Cubic polynomial)
    %(i.e: '-dot-rbg'  i.e.  '-rbg')
    
    %Kweights, the weights for every kernel, the higher the weight of a
    %kernel with respect to the others, the more impact it will have on the
    %Support Vectors compared to the other kernels, there must be 1 weight
    %for each kernel:
    %(i.e: '-0.5-0.5'  i.e.  '-1')

    %minAlpha represents the min value of alpha to be considered a support
    %vector, numbers seem to be really close to 0 but not 0 when they are
    %not support vectors
    
    %print kernel, either false or true, if true it will display a
    %grayscale image of the kernel so you can see how it behaves

%OUTPUTS:
    %W and Wo parameters of the perceptron
    %Indexes, is the list of indexes of the support vectors among the data
    %samples in the DataSet
    %index is the index of the main support vector
function [W,Wo,Indexes,index] = nonlinear_SVM(DataSet, labels, c, kernels, Kweights, minAlpha, printKernel)
    %Paramters for the quadratic programming
        N=size(DataSet,1);
        %Get H based on Kernels selection:
            lenk=size(kernels,2);
            kernels=kernels(2:1:lenk);
            lenkw=size(Kweights,2);
            Kweights=Kweights(2:1:lenkw);
            KArray=strsplit(kernels,'-');
            KWArray=str2double(strsplit(Kweights,'-'));
            %Normalize weights
            KWArray=KWArray./sum(KWArray);
            H=zeros(N); %empty kernel, all kernels are size NxN
            %find each kernel and do a weighted addition
                %Dot Product Kernel (Inner Product)
                    Kindex=find(strcmp(KArray,'dot'));
                    if size(Kindex,2)>0
                        H=H+KWArray(Kindex)*(DataSet*DataSet'.*(labels'*labels));
                    end
                %RBF Kernel (Radial Based Function)
                    Kindex=find(strcmp(KArray,'rbf'));
                    if size(Kindex,2)>0
                        mean=sum(sum(DataSet))/(N^2);
                        variance=sum(sum((DataSet-mean).^2))/(N^2);
                        expanded=DataSet*ones(size(DataSet))';
                        if variance>0
                            H=H+KWArray(Kindex)*exp(-((expanded-expanded').^2)/variance);
                        end
                    end
                %POLY2 (QUADRATIC POLYNOMIAL)
                    Kindex=find(strcmp(KArray,'poly2'));
                    if size(Kindex,2)>0
                        H=H+KWArray(Kindex)*((DataSet*DataSet').^2).*(labels'*labels);
                    end
                %POLY3 (QUADRATIC POLYNOMIAL)
                    Kindex=find(strcmp(KArray,'poly3'));
                    if size(Kindex,2)>0
                        H=H+KWArray(Kindex)*((DataSet*DataSet').^3).*(labels'*labels);
                    end
        %Print Kernel
            if printKernel
                img=uint8(255*H./max(H));
                figure;
                imshow(img);
            end
        %Rest of parameters of Quadratic Programming
        f=-ones(N,1);
        A=eye(N);
        b=c*ones(N,1);
        Aeq=[labels;zeros(N-1,N)];
        beq=zeros(N,1);
        lb=zeros(N,1);
        ub=[];
    %Quadratic programmin returns the lagrange multipliers where support
    %vectors have alpha>0, 0 otherwise
        alpha=quadprog(H+eye(N)*0.001,f,A,b,Aeq,beq,lb,ub);
    %Index of support vectors
        Indexes=find(alpha>minAlpha);
    %Calculate perceptron parameters
        W=(alpha.*labels')'*DataSet;
        %Regardless of which support vector is used, the slope of the
        %decision hyperplane is fixed!
        %-
        %For all the support vectors, count the items that were correctly
        %classified and whichever support vector provides the most, will be
        %used to calculate Wo as the main support vector
        highestC=0;
        index=Indexes(1);
        for i=1:size(Indexes,1)
            Wo_temp=1/labels(Indexes(i))-(W*DataSet(Indexes(i),:)');
            %Array of Perceptrons for all samples:
            g=(W*DataSet')+Wo_temp;
            %transform g into classification labels,1 for class 1 -1
            %otherwise
            c1=g>=0;
            c2=-(g<0);
            cLabels=c1+c2;
            C_Rate=sum(labels.*cLabels); %Correctly classified-incorrectly classified
            if C_Rate>highestC
                highestC=C_Rate;
                index=Indexes(i);
            end
        end
        %Wo of the best support Vector given W
        Wo=1/labels(index)-(W*DataSet(index,:)');
end