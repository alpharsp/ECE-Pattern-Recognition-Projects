classdef IndexedArray
    %This class was created to generate object that can hold an array and
    %an index value
    properties
        index;
        Array;
    end
    
    methods
        function obj=IndexedArray(MyIndex,MyArray)
            obj.index=MyIndex;
            obj.Array=MyArray;
        end
    end
    
end

