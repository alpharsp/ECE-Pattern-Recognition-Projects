classdef IndexedArrays
    %This class is a container of IndexedArray objects
    properties
        index;
        IArray;
    end
    
    methods
        function obj=IndexedArrays(MyIndex,MyIArray)
            obj.index=MyIndex;
            obj.IArray=MyIArray;
        end
    end
    
end

