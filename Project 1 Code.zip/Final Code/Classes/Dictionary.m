classdef Dictionary
    %This class was created to generate object that can hold an array and
    %an index value
    properties
        rows;
        keys=string.empty(0);
        items;
    end
    methods
        function obj=Dictionary()
            obj.rows=0;
        end
        function obj= add(obj,key,item)
            obj.rows=obj.rows+1;
            obj.keys(obj.rows)=key;
            obj.items(obj.rows)=item;
        end
        function out=exists(obj,key)
            i=1;
            out=false;
            while (i<=obj.rows) && (out==false)
                currentKey=obj.keys(i);
                if currentKey==key
                    out=true;
                end
                i=i+1;
            end
        end
        function out=item(obj,key)
            i=1;
            out=false;
            while (i<=obj.rows) && (out==false)
                currentKey=obj.keys(i);
                if currentKey==key;
                    out=obj.items(i);
                end
                i=i+1;
            end
        end
    end
end

