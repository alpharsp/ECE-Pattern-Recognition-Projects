%INCLUDE CLASSES AND FUNCTIONS
    addpath('Functions','Classes');
%USER INPUTS
    %This example contains 3 different Datasets:
        %(1) Two_Class_FourDGaussians2
        %(2) Iris
        %(3) Wine
    %FILE LOCATIONS, FEATURE NAMES AND LABEL COLUMN
    %Select File location for each dataset and the label column number,  
    %which stablishes which column in the original data contains labels
        %FileLocations
            FileLoc=string.empty(3,0);
            FileLoc(1)='dataSets/Two_Class_FourDGaussians2.dat';
            FileLoc(2)='dataSets/bezdekIris.data';
            FileLoc(3)='dataSets/wine.data';
        %Name of features
            fNames=IndexedArray.empty(3,0);
            fNames(1)=IndexedArray(1,[string('Feature 1'),string('Feature 2'),string('Feature 3'),string('Feature 4')]);
            fNames(2)=IndexedArray(2,[string('Sepal Length'),string('Sepal Width'),string('PetalLength'),string('Petal Width')]);
            fNames(3)=IndexedArray(3,[string('Alcohol'),string('Malic acid'),string('Ash'),string('Alcalinity of ash'),string('Magnesium'),string('Total phenols'),string('Flavanoids'),string('Nonflavanoid phenols'),string('Proanthocyanins'),string('Color intensity'),string('Hue'),string('OD280/OD315 of diluted wines'),string('Proline')]);
        %LabelColumns
            LabelCol=[5,5,1];
    %LOSS MATRIX provide one for each dataset
        Losses=IndexedArray.empty(3,0);
        Losses(1)=IndexedArray(1,1-eye(2));
        Losses(2)=IndexedArray(1,1-eye(3));
        Losses(3)=IndexedArray(1,1-eye(3));
    %COLORS FOR PLOT
        usableColors=['r','g','b']; %If data has more than 3 classes need to
                                %expand the number of usable colors
    %SELECT DATASET TO USE
        dataset=3;
    %SELECT FEATURES TO USE
        %You can use either all the features from the dataset or only
        %certain features
            useAll=true;
        %if useAll==false then the following array will be used to
        %determine wich features will be used:
            fToUse=[1,2];
    %PLOT
        %If should plot is true, the program will create a 3D and/or 2D plot with the
        %first 3 and/or 2 features of the dataset, set true if the data has at least
        %3 features, set it false otherwise
        shouldPlot3=false;
        shouldPlot2=true;
    %SHUFFLE TEST DATA
        %if set to yes, the data used will be suffle before starting with
        %the overal cross validation (It wont affect the cross validation, 
        %it will just make things more fare)
        shouldShuffle=false;
%-------------------------------------------------------------------------
%-------------------------------------------------------------------------
%EXTRACTING DATA AND LABELS
    %Label column stablishes which of the columns in the original data
    %contains the label
    [Data,Labels]=readDataset(FileLoc(dataset),LabelCol(dataset));
%RESTRIC FEATURES
    if not(useAll)
        Data=Data(:,fToUse);
        tempNames=fNames(dataset).Array;
        fNames(dataset).Array=tempNames(fToUse);
    end
%GENERAL INFO OF THE DATA
    %NUMBER OF SAMPLES AND NUMBER OF FEATURES
        [totSamples,totFeatures]=size(Data);
    %TOTALNUMBER OF CLASSES
        uniqueClasses=unique(Labels);
        totalClasses=size(uniqueClasses,1); 
%LOSSMATRIX (User Input)
       %Impact of classifying a class incorrectly
        Loss=Losses(dataset).Array;
%FEATURE NAMES
    f_Names=fNames(dataset).Array;
%-------------------------------------------------------------------------
    totalParts=10;
%DATA TO RECORD
    %MEANS AND COVARIANCE MATRICES
        %allDataM IndexedArray object (1 item per class) where each item is the
                % Array of means of the features
        %allDataE IndexedArray object (1 item per class) where each item is the
                % Covariance Matrix of the features for that class
        crossValM=IndexedArrays.empty(totalParts,0);
                %IndexedArrays object containing 10 Indexed Array objects, one
                %for each classifier on the Cross Validation Testing, each
                %IndexedArray object has the arrays of means of the features
                %for each of the classes
        crossValE=IndexedArrays.empty(totalParts,0);
                %IndexedArrays object containing 10 Indexed Array objects, one
                %for each classifier on the Cross Validation Testing, each
                %IndexedArray object the Covariance Matrices of the features for 
                % each of the classes on that classifier
    %CONFUSION MATRICES
        %ADConfM    All Data Confusion Matrices
        CrossValCM=IndexedArray.empty(totalParts,0); %All confusion Matrices
                %for the 10 classifiers in cross Validation
    %ERROR ESTIMATES
        %Error %Error Estimate for the substitution testing
        %AllErrors %Array of Error Estimates for each of the classifiers on the
                  %Cross Validation
    %CLASSIFICATION INFORMATION ON THE TEST VECTORS
        %ADClassification Array of classified items (one for each sample)
        %using the substitution testing classifier
        CVClassification=IndexedArray.empty(totalParts,0); %IndexedArray
            %object where each item is an Array of Classified items using
            %the cross validation testing classifiers
    %AVERAGE RATES
        %ADACCR Average of the correct classifaction rates using all data
        CVACCR=zeros(totalParts,1); %Array with the Average of the correct classifaction rates
                %of each of the Classifiers in the Cross Validation testing
        %ADAFAR Average of the False Alarm Rates using all data
        CVAFAR=zeros(totalParts,1); %Array with the Average of the False Alarm Rates
                %of each of the Classifiers in the Cross Validation testing
                
%-------------------------------------------------------------------------
%-------------------------------------------------------------------------
%SUBSTITUTION TESTING
%Train the classifier using all the available data and then test it trying
%to classify all the data that was used during the training
     %CLASSES PROBABILITY Calculate overall probability of Class Wi showing up
         ClassProb = OverallCProb(Labels);
     %GET BAYES PARAMETERS (Mean Array of features and Covariance Matrix for each class)
        [ ClassesM, ClassesE ] = ReturnBayesParameters(Data, Labels);
        allDataM=ClassesM;
        allDataE=ClassesE;
     %CLASSIFY EACH SAMPLE (Array with each sample classified "Name of class"
        ADClassification=BMRClassify(Data, uniqueClasses, Loss, ClassesM, ClassesE, ClassProb);
     %RESUBSTITUTION ERROR CALCULATION
        ADClassification=ADClassification';
        SuccessArray=Labels==ADClassification; %Array with ones and ceros where the 
                                    %ones are the samples correctly classified
        ErrorArray=(1-SuccessArray);
        totalErrors=sum(ErrorArray);
        Error=totalErrors*100/totSamples;
        'SUBSTITUTION TESTING ERROR: ' + string(Error) + '%'
     %CREATE CONFUSION MATRIX
        ADConfM=ConfusionMatrix(uniqueClasses,ADClassification,Labels);
     %AVERAGE CLASSIFICATION RATES
        [ADACCR,ADAFAR] = AClassificationRates(ADConfM);
%-------------------------------------------------------------------------
%-------------------------------------------------------------------------
%CROSS VALIDATION
%Divide the entire data in 10 parts, then create 10 classifiers using 9
%consecutive parts of the data, each classifier will use the 10 different
%combinations of those parts
    %Shuffle the data at the begining to be fair
    if shouldShuffle
        randomVector=randperm(totSamples);
        sData=Data(randomVector,:);
        sLabels=Labels(randomVector,:);
    else
        sData=Data;
        sLabels=Labels;
    end
    %Distribute the samples as equally as possible
        splitData=IndexedArray.empty(totalParts,0);
        splitLabels=IndexedArray.empty(totalParts,0);
        samplesForAll=floor(totSamples/totalParts);
        oneExtra=mod(totSamples,totalParts);
        lastEnd=0;
        for i=1:totalParts
            newEnd=lastEnd+samplesForAll+(i<=oneExtra);
            sampVec=(lastEnd+1:newEnd);
            lastEnd=newEnd;
            splitData(i)=IndexedArray(i,sData(sampVec,:));
            splitLabels(i)=IndexedArray(i,sLabels(sampVec,:));
        end
   %Create 10 different Classifiers
        AllErrors=zeros(totalParts,1);
        for i=1:totalParts
            %Everything inside the for belongs to a single Classifier
            testIndex=i;
            %Test Data
                testData=splitData(testIndex).Array;
                testLabels=splitLabels(testIndex).Array;
                testSize=samplesForAll+(testIndex<=oneExtra);
            %Training Data
                trainingSize=totSamples-testSize;
                trainingData=zeros(trainingSize,totFeatures);
                trainingLabels=string.empty(trainingSize,0);
                lastRow=0;
                for j=1:totalParts
                    if(j~=testIndex)
                        firstRow=lastRow+1;
                        lastRow=firstRow+size(splitData(j).Array,1)-1;
                        trainingData(firstRow:lastRow,:)=splitData(j).Array;
                        trainingLabels(firstRow:lastRow)=splitLabels(j).Array;
                    end
                end
                trainingLabels=trainingLabels';
             %CLASSES PROBABILITY Calculate overall probability of Class Wi showing up
                 ClassProb = OverallCProb(trainingLabels);
             %GET BAYES PARAMETERS (Mean Array of features and Covariance Matrix for each class)
                [ ClassesM, ClassesE ] = ReturnBayesParameters(trainingData, trainingLabels);
                crossValM(i)=IndexedArrays(i,ClassesM);
                crossValE(i)=IndexedArrays(i,ClassesE);
             %CLASSIFY EACH SAMPLE (Array with each sample classified "Name of class")
                SubDecision=BMRClassify(testData, uniqueClasses, Loss, ClassesM, ClassesE, ClassProb);
             %RESUBSTITUTION ERROR CALCULATION
                SubDecision=SubDecision';
                CVClassification(i)=IndexedArray(i,SubDecision);
                SuccessArray=testLabels==SubDecision; %Array with ones and ceros where the 
                                            %ones are the samples correctly classified
                ErrorArray=(1-SuccessArray);
                totalErrors=sum(ErrorArray);
                Error=totalErrors*100/testSize;
                %'CROSS VALIDATION ' + string(i) + ' TESTING ERROR: ' + string(Error) + '%'
                AllErrors(i)=Error;
            %CREATE CONFUSION MATRIX
                CrossValCM(i)=IndexedArray(i,ConfusionMatrix(uniqueClasses,SubDecision,testLabels));
            %AVERAGE CLASSIFICATION RATES
                [CVACCR(i),CVAFAR(i)] = AClassificationRates(CrossValCM(i).Array);
        end
        'CROSS VALIDATION TESTING ERROR (%): '
        AllErrors
%--------------------------------------------------------------------------
%--------------------------------------------------------------------------
%PLOTS
    %PLOT THE FIRST 3 FEATURES OF ALL DATA if wanted
    if shouldPlot3
        Points=IndexedArray.empty(totalClasses,0);
        figure;
        for k=1:totalClasses
           %Class k Data:
           thisColor=usableColors(k);
           class=uniqueClasses(k);
           ClassPoints=Data(Labels==class,:);
           scat(k)=scatter3(ClassPoints(:,1),ClassPoints(:,2),ClassPoints(:,3),20,thisColor);
           if k==1
               hold;
           end
        end
            legend(scat(1:totalClasses),uniqueClasses);
            xlabel(f_Names(1));ylabel(f_Names(2));zlabel(f_Names(3));
            hold;
    end
    %PLOT THE FIRST 2 FEATURES OF ALL DATA if wanted
    if shouldPlot2
        Points=IndexedArray.empty(totalClasses,0);
        figure;
        for k=1:totalClasses
           %Class k Data:
           thisColor=usableColors(k);
           class=uniqueClasses(k);
           ClassPoints=Data(Labels==class,:);
           scat(k)=scatter(ClassPoints(:,1),ClassPoints(:,2),20,thisColor);
           if k==1
               hold;
           end
        end
            legend(scat(1:totalClasses),uniqueClasses);
            xlabel(f_Names(1));ylabel(f_Names(2));
            hold;
    end
