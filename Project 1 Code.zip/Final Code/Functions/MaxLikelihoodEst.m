function [ M, E ] = MaxLikelihoodEst( ClassSamples)
%The samples are expected to come in a single matrix where each row is a
%different sample and every column is a feature of each sample
%-----------------------------------------------------------------------
[totalSamples,totalFeatures]=size(ClassSamples);
%CALCULATE MEAN
%First need to calculate a Mean vector which contains the mean of each
%feature (Dimension) considering all the provided samples
    AddedSamples=zeros(1,totalFeatures);
    for i=1:totalSamples
        currentSample=ClassSamples(i,:);
        AddedSamples=AddedSamples+currentSample;
    end
    %M is an array where each element is the mean of each dimension
    %(feature)
    M=(AddedSamples/totalSamples);
%CALCULATE COVARIANCE MATRIX
%This matrix is going to have the standard deviation of each dimension as
%the main diagonal
    AddedMatrix=zeros(totalFeatures,totalFeatures);
    for i=1:totalSamples
        currentSample=ClassSamples(i,:);
        Subs=(currentSample-M);
        AddedMatrix=AddedMatrix+(Subs'*Subs);%First the vertical then 
        %horizontal to get the matrix
    end
    E=AddedMatrix/totalSamples;
end

