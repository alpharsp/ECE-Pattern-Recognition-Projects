function PP = PriorProbability (Sample,M,E)
%THIS FUNCTION CREATES A NORMAL PDF (PROBABILITY DENSITY FUNCTION)FOR 1 CLASS
%USING THE PROVIDED VECTOR OF MEANS (ONE MEAN FOR EACH FEATURE) AND THE COVARIANCE
%MATRIX E
%THIS IS DESCRIBED AS THE PROBABILITY OF GETTING X COMBINATION OF FEATURES
%GIVEN THE DISTRIBUTION OF CLASS Wi
%Sample is a single sample vector with D features
%-------------------------------------------------------------------------
D=size(M,1); %Number of Dimensions (Features)
PP=(1/(((2*pi)^(D/2))*sqrt(det(E))))*exp((-1/2)*(Sample-M)*inv(E)*(Sample-M)');
end