function CD = ClassData(Data,Labels,ClassName)
    %This function returns a Matrix CD which is a submatrix of the
    %DataMatrix containing only the samples of a given ClassName, for it to
    %work, Matrix Data and Vector Labels need to have the same number of
    %rows and be ordered in such a way that they share the same sample
    %index
    %---------------------------------------------------------------------
    %COUNT TOTAL NUMBER OF SAMPLES
        totalRows=size(Labels);
        totalRows=totalRows(1);
        classRows=0;
        for i=1:totalRows
            if Labels(i)==ClassName
                classRows=classRows+1;
            end
        end
    %GENERATE MATRIX
        totalFeatures=size(Data);
        totalFeatures=totalFeatures(2);
        CD=zeros(classRows,totalFeatures);
        classRow=0;
        for i=1:totalRows
            if Labels(i)==ClassName
                classRow=classRow+1;
                CD(classRow,:)=Data(i,:);
            end
        end
end