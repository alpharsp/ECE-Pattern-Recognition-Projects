function [ ClassesM, ClassesE ] = ReturnBayesParameters(Data, Labels)
    %TOTALNUMBER OF CLASSES
        uniqueClasses=unique(Labels);
        totalClasses=size(uniqueClasses);
        totalClasses=totalClasses(1);
    %DATA TRAINING
        %Estimate mean and Covariance Matrix for each class which latter
        %will be used to generate the prior likelihood function of the
        %classifier.
        ClassesM=IndexedArray.empty(totalClasses,0);
        ClassesE=IndexedArray.empty(totalClasses,0);
        for i=1:totalClasses
            %Generates a Submatrix of Data which contains only the data for
            %the Wi class
            CD=ClassData(Data,Labels,uniqueClasses(i));
            %Store Mean and Covariance Matrix for class Wi
            [M,E]=MaxLikelihoodEst(CD);
                Mtemp=IndexedArray(i,M);
                Etemp=IndexedArray(i,E);
            ClassesM(i)=Mtemp;
            ClassesE(i)=Etemp;
        end
end