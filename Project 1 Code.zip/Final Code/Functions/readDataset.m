%%This is my personal Function created to extract data from datasets
%%If needed it will be improved with the time to fit on most data
%%structures, right now it can detect data and labels for space and comma 
%%separators as long as the user knows which column on the data belongs to
%%the labels. The user doesnt need to know the size of the data.
%%------------------------------------------------------------------------
function [Data,labels] = readDataset(fileLocation, labelColumn)
    %OPEN FILE AS A STRING
    fileLocation=char(fileLocation); %Converts from string to char vector
    text=fileread(fileLocation);
    %SET SEPARATIONS AS COMMAS
        spaces=size(strfind(text,'  '));
        spaces=spaces(1,2);
        while (spaces>0)
            text=replace(text,'  ',' ');
            spaces=size(strfind(text,'  '));
            spaces=spaces(1,2);
        end
        text =replace(text,' ',',');
    %DEFINE LINE SEPARATIONS AS '|'
        text=replace(text,char(10),'|');
        text =replace(text,char(13),'|');
        ds=size(strfind(text,'||'));
        ds=ds(1,2);
        while (ds>0)
            text=replace(text,'||','|');
            ds=size(strfind(text,'||'));
            ds=ds(1,2);
        end
    %ELIMINATE UNNECESARY COMMAS AND LINE SEPARATORS
        text=replace(text,'|,','|');
        text=replace(text,',|','|');
        while((text(1:1)==',') || (text(1:1)=='|'))
            text=text(2:length(text));
        end
        while((text(length(text):length(text))==',') || (text(length(text):length(text))=='|'))
            text=text(1:length(text)-1);
        end
    %GET NUMBER OF ROWS AND NUMBER OF COLUMNS
        rows=length(text)-length(replace(text,'|',''))+1;
        i=1;
        cols=0;
        while (text(i:i) ~= '|')
            i=i+1;
            if (text(i:i)==',')
                cols=cols+1;
            end
        end
        cols=cols+1;
    %CREATE DATA MATRIX AND LABELS TO RETURN
        lines=string(strsplit(text,'|'));
        labels=zeros(1,rows);
        labels=string(labels);
        Data=zeros(rows,cols-1);
        for i=1:rows
            currentCols=strsplit(lines(i),',');
            labels(i)=currentCols(labelColumn);
            colCounter=1;
            for j=1:cols
                if j~=labelColumn
                    Data(i,colCounter)=currentCols(j);
                    colCounter=colCounter+1;
                end
            end
        end
        labels=labels';
end