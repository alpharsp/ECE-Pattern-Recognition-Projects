function Classifications = BMRClassify(DataToClassify, uniqueClasses, LossMatrix, ClassesM, ClassesE, ClassProb)
%This function returns a unidimensional array with length equal to the
%number of samples in the Datatoclassify, it will return the name of the
%classified as the minimum risk option using the features from the data,
%the loss matrix, the overallprobability of each class and the Normal
%Distribution parameters for each class (Array of means for each parameter
%and the covariance matrix of the parameters)

 %NUMBER OF SAMPLES AND NUMBER OF FEATURES
    totSamples=size(DataToClassify,1);
 %TOTALNUMBER OF CLASSES
    totalClasses=size(uniqueClasses,1);
 %START CLASSIFYING
    Classifications=string.empty(totSamples,0);
    
 %TEST YOUR CLASSIFIER BY CLASSIFYING ALL OF YOUR TRAINING DATA
            Likelihood=zeros(totalClasses,1);
            %for each Sample
            for i=1:totSamples
                Risk=zeros(totalClasses,1);
                Sample=DataToClassify(i,:);
                %SAMPLE PROBABILITY
                    %Probability of finding the combination of features from
                    %current sample in all the space (Marginalize it from likelihoods)
                    AddedLikelihood=0;
                    for j=1:totalClasses
                        Likelihood(j)=PriorProbability(Sample,ClassesM(j).Array,ClassesE(j).Array);
                        AddedLikelihood=AddedLikelihood+Likelihood(j);
                    end
                    SampleProb=AddedLikelihood;
                %BAYES PROBABILITY (ONE FOR EACH CLASS)
                    BayesProb=(Likelihood.*ClassProb)/SampleProb;
                %MINIMUM RISK CALCULATION
                    %Risk Ri of Classifying currentSample as class Wi
                    %considering the Loos Matrix
                    MinRisk=1;
                    for j=1: totalClasses
                        for k=1:totalClasses
                            Risk(j)=Risk(j)+(LossMatrix(j,k)*BayesProb(k));
                        end
                        if j>1
                            if Risk(j)<Risk(j-1)
                                MinRisk=j;
                            end
                        end
                    end
                    %Classify Sample as the one with the minimum Risk
                    Classifications(i)=uniqueClasses(MinRisk);
            end
end