function [ACCR,AFAR] = AClassificationRates( ConfusionMatrix )
    sumaCC=0;
    sumaFA=0;
    count1=0;
    count2=0;
    classes=size(ConfusionMatrix,1);
    for i=1:classes
        %For Each Class
        correctlyClassified=ConfusionMatrix(i,i);
        totalofClass=sum(ConfusionMatrix(:,i));
        ClassifiedAsClass=sum(ConfusionMatrix(i,:));
        ClassifiedIncorrectly=ClassifiedAsClass-correctlyClassified;
        if totalofClass>0
            sumaCC=sumaCC+(correctlyClassified/totalofClass);
            count1=count1+1;
        end
        if ClassifiedAsClass>0
            sumaFA=sumaFA+(ClassifiedIncorrectly/ClassifiedAsClass);
            count2=count2+1;
        end
    end
    ACCR=sumaCC/count1;
    AFAR=sumaFA/count2;
end

