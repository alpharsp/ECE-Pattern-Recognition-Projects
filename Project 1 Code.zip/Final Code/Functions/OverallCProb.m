function ClassProb = OverallCProb(Labels)
    %Calculate overall probability of Class Wi showing up
            %Total Number of Classes
                uniqueClasses=unique(Labels);
                totalClasses=size(uniqueClasses,1);
            %Total Samples
                totSamples=size(Labels,1);
            %Probability
                ClassProb=zeros(totalClasses,1);
                for i=1:totSamples
                    currentLabel=Labels(i);
                    for j=1:totalClasses
                        if currentLabel==uniqueClasses(j)
                                ClassProb(j)=ClassProb(j)+1;
                        end
                    end
                end
                ClassProb=ClassProb/totSamples;
end