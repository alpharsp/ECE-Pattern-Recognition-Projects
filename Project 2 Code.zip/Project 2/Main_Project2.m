%THIS IS THE SVM FOR 1 CLASS WHICH MEANS IT WILL TELL US WETHER AN ELEMENT
%ON THE TEST DATASET BELONGS TO CLASS 1 OR NOT, IT CAN BE USED AS A LAYER
%OF A MULTICLASS CLASSIFICATION ALGORITHM OR DIRECTLY AS A 2 CLASS
%CLASSIFIER.
%DATA AND LABELS MUST BE IN FORM OF COLUMN VECTORS
%LABELS MUST BE 1 FOR CLASS 1, -1 OTHERWISE
%-------------------------------------------------------------------------
%INCLUDE CLASSES AND FUNCTIONS
    addpath('Functions');
%--------------------------------------------------------------------------
%USER PARAMETERS
  %c Weight: weight for the classification error on the quadratic program
    c=1*10^(0);
  %Parameters for Kernels
    rbf_sigma=30; %sigma in rbf kernel
    poly_Const=1; %Constant in the polynomial
    minAlpha=1*10^(-3); %min value of lagrange multiplier to be a SupportVector
    %this more or less controls the number of support vectors, the lower
    %the number the more support vectors we will end up using this number
    %can be very sensitive
  %Kernel Combinations
    KernelOptions='-dot-rbf-poly2-poly3';
    Kweights='-1-0-0-0';
  %PLATFORM: the options are either 'octave' or 'matlab'
    platform='matlab';
  %Dimensions to plot: only 2 features will be used for the 2D image
    d1=1; %horizontal
    d2=2; %vertical
  %Classification of scaled data
    scale=true;
    ImageWidth=800;
  %Resubstitution and/or cross validation
      resubstitution=true;
      crossValidation=true;
      folds=10;
%--------------------------------------------------------------------------
%READ DATASET
    %SAMPLES:
       %GET DATASET FROM IMAGE
          %RedPoints have label=1, Blue Points have label=-1
          %[DataSet,labels]=RBImageToDataset();
       %READ AN IMAGE AND EXPORT IT AS A DATASET
          %exportRBData();
       %READ DATASET FILE
          labelCol=101;
          c1=char('1'); %LABEL OF CLASS
          %c1=char('Iris-versicolor'); %LABEL OF CLASS
          disp('Select Dataset to read');
          [DataSet,labels] = readDataset(labelCol, platform, c1);
%--------------------------------------------------------------------------
%RESUBSTITUTION TESTING
%------------------------------
%Resubstitution
if resubstitution
    if size(DataSet,1)>0
        %CLASSIFICATION
        [Errors,ConfM,ACCR,AFAR,MC]=classifyOriginal(DataSet,labels,DataSet,labels,c,rbf_sigma,poly_Const,minAlpha,KernelOptions,Kweights,platform);
        %2D VISUALIZATION AND SCALED CLASSIFICATION
        Image2D(DataSet,labels,DataSet,labels,c,rbf_sigma,poly_Const,minAlpha,KernelOptions,Kweights,platform,d1,d2,scale,ImageWidth,MC);
        disp('Total errors:');
        disp(Errors);
        disp('Confusion Matrix:');
        disp(ConfM);
        disp('Average Correct Classification Rate:');
        disp(ACCR);
        disp('Average False Alarm Rate:');
        disp(AFAR);
    else
        disp('Image Data not found or read Incorrectly');
    end
end
%CROSS VALIDATION (N Folds)
if crossValidation
    if size(DataSet,1)>0
        totalErrors=zeros(1,folds);
        foldsConfM=zeros(size(DataSet,2),size(DataSet,2),folds);
        foldsACCR=zeros(1,folds);
        foldsAFAR=zeros(1,folds);
        %create the N Datasets
        [total,d]=size(DataSet);
        minItems=floor(total/folds);
        SamplesMax=total-(minItems*folds);
        %Samples is a array of N folds rows x d features cols in cell
        %format each containing each of the folds
        Samples=mat2cell(DataSet,([ones(1,SamplesMax),zeros(1,folds-SamplesMax)]+(ones(1,folds)*minItems))',d);
        etiquetas=mat2cell(labels,([ones(1,SamplesMax),zeros(1,folds-SamplesMax)]+(ones(1,folds)*minItems))',1);
        for i=1:folds
            %disp('Fold ' + string(i));
            indexPointer=(1:1:folds)';
            trainData=cell2mat(Samples(find(indexPointer~=i),:));
            trainLabels=cell2mat(etiquetas(find(indexPointer~=i),:));
            testData=cell2mat(Samples(i,:));
            testLabels=cell2mat(etiquetas(i,:));
            [totalErrors(i),tempCM,foldsACCR(i),foldsAFAR(i),tempMC]=classifyOriginal(trainData,trainLabels,testData,testLabels,c,rbf_sigma,poly_Const,minAlpha,KernelOptions,Kweights,platform);
        end
        disp('Total errors:');
        disp(totalErrors);
        disp('Average Correct Classification Rate:');
        disp(foldsACCR);
        disp('Average False Alarm Rate:');
        disp(foldsAFAR);
    else
        disp('Image Data not found or read Incorrectly');
    end
end


