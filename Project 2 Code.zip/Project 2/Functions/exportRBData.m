function exportRBData()
  [DataSet,Labels]=RBImageToDataset();
  [file,path]=uiputfile('.txt','Save Dataset','Red_Blue_Dataset.txt');
  fileLocation=[path,file];
  R=Labels>0;
  Rindex=find(R);
  B=Labels<0;
  Bindex=find(B);
  RData=DataSet(Rindex,:);
  BData=DataSet(Bindex,:);
  fid=fopen(fileLocation,'w');
  fprintf(fid,'%.4f   %.4f   red\r\n',RData');
  fprintf(fid,'%.4f   %.4f   blue\r\n',BData');
  fclose(fid);
end