function Matrix=ConfusionMatrix(uniqueClasses,ClassifiedArray,LabelsArray)
        totSamples=size(LabelsArray,1);
        totalClasses=size(uniqueClasses,1);
        Matrix=zeros(totalClasses);
        classesDic=Dictionary();
        for i=1:totalClasses
            classesDic=classesDic.add(uniqueClasses(i),i);
        end
        for i=1:totSamples
            classAs=ClassifiedArray(i);
            ActualClass=LabelsArray(i);
            ClassifiedIndex=classesDic.item(classAs);
            ActualIndex=classesDic.item(ActualClass);
            Matrix(ClassifiedIndex,ActualIndex)=Matrix(ClassifiedIndex,ActualIndex)+1;
        end
end