function img = backImage(Xscale,Yscale,imgDataSet,supportVectors,SValpha,SVlabels,Wo,KernelOptions,KernelWeights,rbf_sigma,poly_Const)
        %Boundaries of Image
            minx=floor(min(imgDataSet(:,1)));maxx=ceil(max(imgDataSet(:,1)));
            miny=floor(min(imgDataSet(:,2)));maxy=ceil(max(imgDataSet(:,2)));
        %Color everyPixel
            xAxis=minx:1:maxx;
            yAxis=(miny:1:maxy)';
            rows=maxy-miny+1;
            cols=maxx-minx+1;
            xyMatrix(:,:,1)=ones(rows,1)*xAxis;
            xyMatrix(:,:,2)=yAxis*ones(1,cols);
            %Ordered list of all the pixels p11,p12,...,p1maxX,p21,p22,...pmaxYmaxX
            pixels=[];
            for i=1:rows
              rowElements=zeros(2,cols);
              rowElements(1,:)=xyMatrix(i,:,1);
              rowElements(2,:)=xyMatrix(i,:,2);
              pixels=[pixels;rowElements'];
            end
            %Equivalent to the pixels but with the real data scale this is
            %the data that will actually be classified
            eqPixels=[pixels(:,1)./Xscale,pixels(:,2)./Yscale];
            %this is a kernel where the rows are the support vectors and the
            %columns are the points to evaluate under the discriminant function g(x)
            %this needs to be done this way because kernels that are not dot functions$could've been used
            kernel=getKernel(supportVectors,eqPixels,KernelOptions,KernelWeights,rbf_sigma,poly_Const);
            g=(SValpha.*SVlabels)'*kernel; %this is equivalent to W'*X in the discriminant function
            g=g+Wo;  %this is equivalent to W'*X+Wo in the discriminant function
            %put back g(x) in its matrix form so for each coordinate we know whats the value g(x)
            counter=1;
            gmatrix=zeros(rows,cols);
            for i=1:rows
              rowElements=g(1,counter:1:counter+cols-1);
              gmatrix(i,:)=rowElements;
              counter=counter+cols;
            end
            %Dark red on red margin
                redBack1=gmatrix>0;
                redBack1=60.*redBack1;
                blueBack1=gmatrix<0;
                blueBack1=60.*blueBack1;
            %Further than the Margin
                redBack2=gmatrix>=1; 
                redBack2=180*(redBack2.*gmatrix)/max(max(gmatrix));
                blueBack2=gmatrix<=-1; 
                blueBack2=180*(blueBack2.*gmatrix)/min(min(gmatrix));
            %Add Reds/Blues
                redBack=redBack1+redBack2;
                blueBack=blueBack1+blueBack2;
            %Green Decision Line
                greenBack1=gmatrix>=-0.05; 
                greenBack2=gmatrix<=0.05; 
                %greenBack=zeros(size(blueBack));%
                greenBack=and(greenBack1,greenBack2)*255;
            %Not as bright Margin line
                greenBack1=abs(gmatrix)>=0.9; 
                greenBack2=abs(gmatrix)<=1.1; 
                greenBack=greenBack+and(greenBack1,greenBack2)*125;
            %Cap at 255
            redBack=((redBack>255).*255)+((redBack<=255).*redBack);
            blueBack=((blueBack>255).*255)+((blueBack<=255).*blueBack);
            greenBack=((greenBack>255).*255)+((greenBack<=255).*greenBack);
            BackColor(:,:,1)=uint8(redBack);
            BackColor(:,:,2)=uint8(greenBack);
            BackColor(:,:,3)=uint8(blueBack);
            img=BackColor;
end