function [Errors,ConfM,ACCR,AFAR,misClassified]=classifyOriginal(trainSet,trainLabels,testSet,testLabels,c,rbf_sigma,poly_Const,minAlpha,KernelOptions,Kweights,platform)
    %SVM THE SVM ITSELF IS MULTY DIMENSIONAL
    %large kernel with all data
    kernel=getKernel(trainSet,trainSet,KernelOptions,Kweights,rbf_sigma,poly_Const);
  %obtain wo Bias using quadratic programming
    [wo,Indexes,alpha]=nonlinear_SVM(trainLabels,kernel,c,minAlpha,platform);
  %get some components for the classification using the lagrange multipliers>0 (alpha)
    supportVectors=trainSet(Indexes,:);
    SValpha=alpha(Indexes,1);
    SVlabels=trainLabels(Indexes,1);
  %classify testpoints
    %kernel with Support vectors against all test data
    skernel=getKernel(supportVectors,testSet,KernelOptions,Kweights,rbf_sigma,poly_Const);
    g=((SValpha.*SVlabels)'*skernel)+wo;%this is equivalent to W'*X+wo in the discriminant function
  %get Incorrectly Classified points
    incorrectIndex=find((g'.*testLabels<0));
    Errors=size(incorrectIndex,1);
  %Misclassified
  misClassified=incorrectIndex;
  %Results Analysis
    wLabels=(testLabels.*((g'.*testLabels<0).*-1));
    resultLabels=testLabels;
    resultLabels(find(wLabels~=0),:)=wLabels(find(wLabels~=0),:);
     %CREATE CONFUSION MATRIX
        ConfM=ConfusionMatrix(string([1;-1]),string(resultLabels),string(testLabels));
     %AVERAGE CLASSIFICATION RATES
        [ACCR,AFAR] = AClassificationRates(ConfM);
end