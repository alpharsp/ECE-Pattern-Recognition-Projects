%%THIS FUNCTION USES QUADRATIC PROGRAMMING TO SOLVE THE NON LINEARLY
%%SEPARABLE SVM PROBLEM, FOR THE INPUT YOU NEED THE KERNEL WHICH CAN BE
%%CREATED USING THE getKernel FUNCTION. c IS THE CONSTANT OF IMPORTANCE FOR
%%THE MINIMIZATION OF THE ERROR (THE HIGHER THE MORE IMPORTANCE IT GIVES TO
%%THE MINIMIZATION OF THE ERROR W.R.T THE MAXIMIZATION OF THE MARGIN).
%%minAlpha IS A NUMBER SLIGHTLY HIGHER THAN 0 FOR THE CONDITION LAMBA>0,
%%DUE TO THE IMPERFECTIONS OF MATLAB AND THE QUADRATIC PROGRAMMING
%%ALGORITHM YOU CANNOT USE 0, TRY WITH 0.0001. PLATFORM IS EITHER 'octave'
%%OR 'MATLAB'.
%%IT RETURNS WO, THE INDEXE OF THE SUPPORT VECTORS AND THE ALPHA VALUE FOR
%%THOSE ECTORS.
function [Wo_avg,Indexes,alpha] = nonlinear_SVM(labels, kernel, c,  minAlpha, platform)
    %Paramters for the quadratic programming
        N=size(labels,1);
        H=kernel.*(labels*labels');
        %Rest of parameters of Quadratic Programming
        f=-ones(N,1);
        %Inequality constraints
          A=eye(N);
          lb=zeros(N,1); 
          ub=c*ones(N,1); 
          b=ub;
        %Equality Constraints
        Aeq=[labels';zeros(N-1,N)];
        beq=zeros(N,1);
    %Quadratic programmin returns the lagrange multipliers where support
    %vectors have alpha>0, 0 otherwise
        if strcmp(platform,'matlab')
          alpha=quadprog(H+eye(N)*0.001,f,A,b,Aeq,beq,lb,ub);
        end
         if strcmp(platform,'octave')
          alpha=qp([],H+eye(N)*0.001,f,Aeq,beq,lb,ub);
         end
        Indexes=find(alpha>minAlpha);
        Wo_avg=0;
        totSV=size(Indexes,1);
        for i=1:totSV
          index=Indexes(i);
          Wo=1/labels(index,1)-sum(alpha.*labels.*kernel(:,index));
          Wo_avg=Wo_avg+Wo;
        end
        Wo_avg=Wo_avg/totSV;
end