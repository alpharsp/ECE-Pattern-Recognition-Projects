%THIS FUNCTION READS AN IMAGE FILE AND FOR EACH PIXEL
%IT DETERMINES IF IT IS PREDOMINANTLY RED OR BLUE. BUILDS A RED
%AND A BLUE DATASETS BASED ON THAT. THE DATASET IS A 2 DIMENSIONAL DATASET
%WITH NO LABELS (SINCE THE DATASETS ARE RETURNED INDEPENDENTLY).
%ONE COLOR HAS TO BE 25 POINTS OUT OF 255 HIGHER IN COLOR THAN THE OTHER
%TO BE CONSIDER PREDOMINANT OTHERWISE IS DISCARDED
function [DataSet,labels] = RBImageToDataset()
    [FileName,Path]=uigetfile({'*.*'});
    imageDir=[Path,FileName];
    ImageM=imread(imageDir);
    %For each pixel in the image check if it's either red or blue
        R=ImageM(:,:,1);
        G=ImageM(:,:,2);
        B=ImageM(:,:,3);
        %RedColor
            Red=R-B;
            Red=Red>25;
            [Redy,Redx]=find(Red); %Row, Column y=Row x=Column
        %BlueColor
            Blue=B-R;
            Blue=Blue>25;
            [Bluey,Bluex]=find(Blue);
    BlueData=[Bluex,Bluey];
    RedData=[Redx,Redy];
    DataSet=[RedData;BlueData];
    labels=[ones(size(RedData,1),1);-1*ones(size(BlueData,1),1)];
end