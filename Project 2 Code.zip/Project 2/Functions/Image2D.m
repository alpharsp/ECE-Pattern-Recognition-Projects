function Image2D(trainSet,trainLabels,testSet,testLabels,c,rbf_sigma,poly_Const,minAlpha,KernelOptions,Kweights,platform,d1,d2,scale,ImageW,MC)
  D2DataSet=trainSet(:,[d1,d2]);
  D2testSet=testSet(:,[d1,d2]);
  %2D PLOTS
    %DataScaling such a way that the image width is always ImageW
    imgDataSet=D2DataSet;
    imgTestSet=D2testSet;
    if scale
        minX=min(min(imgDataSet(:,1)),min(imgTestSet(:,1)));
        minY=min(min(imgDataSet(:,2)),min(imgTestSet(:,2)));
        maxX=max(max(imgDataSet(:,1)),max(imgTestSet(:,1)));
        maxY=max(max(imgDataSet(:,2)),max(imgTestSet(:,2)));
        ImageH=800*(maxY-minY)/(maxX-minX);
        Xscale=ImageW/(maxX-minX);
        Yscale=ImageH/(maxY-minY);
        imgDataSet(:,1)=((imgDataSet(:,1)).*Xscale);
        imgDataSet(:,2)=((imgDataSet(:,2)).*Yscale);
        imgTestSet(:,1)=((imgTestSet(:,1)).*Xscale);
        imgTestSet(:,2)=((imgTestSet(:,2)).*Yscale);
    else
        imgDataSet=trainSet;
        imgTestSet=testSet;
    end
        kernel=getKernel(D2DataSet,D2DataSet,KernelOptions,Kweights,rbf_sigma,poly_Const);
        [wo,Indexes,alpha]=nonlinear_SVM(trainLabels,kernel,c,minAlpha,platform);
        supportVectors=D2DataSet(Indexes,:);
        SValpha=alpha(Indexes,1);
        SVlabels=trainLabels(Indexes,1);
    %PRINT KERNEL
      img=uint8(255.*kernel.*(trainLabels*trainLabels')./max(max(kernel)));
      figure;
      imshow(img);
    %create backImage
      BackColor=backImage(Xscale,Yscale,imgDataSet,supportVectors(:,[1,2]),SValpha,SVlabels,wo,KernelOptions,Kweights,rbf_sigma,poly_Const);
      figure;
      imshow(BackColor);
      hold;
      %Translate datapoints to be relative to the origin
      imgDataSet(:,1)=imgDataSet(:,1)-min(imgDataSet(:,1));
      imgDataSet(:,2)=imgDataSet(:,2)-min(imgDataSet(:,2));
      %Display all vectors
      displayRBPoints(imgDataSet,testLabels,false,platform);
      %Support Vectors
      scatter(imgDataSet(Indexes,1),imgDataSet(Indexes,2),200,'s');
      scatter(imgDataSet(MC,1),imgDataSet(MC,2),200,'white');
      hold;
  axis ij;
end