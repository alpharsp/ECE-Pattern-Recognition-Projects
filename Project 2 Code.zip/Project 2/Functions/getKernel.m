function kernel = getKernel(DataSet,DataSet2,kernelOptions,kernelWeights,rbf_sigma,poly_Const)
          N=size(DataSet,1);
          N2=size(DataSet2,1);
        %Get H based on Kernels selection:
            lenk=size(kernelOptions,2);
            kernelOptions=kernelOptions(2:1:lenk);
            lenkw=size(kernelWeights,2);
            kernelWeights=kernelWeights(2:1:lenkw);
            KArray=strsplit(kernelOptions,'-');
            KWArray=str2double(strsplit(kernelWeights,'-'));
            %Normalize weights
            KWArray=KWArray./sum(KWArray);
            K=zeros(N,N2);
            %find each kernel and do a weighted addition
                %Dot Product Kernel (Inner Product)
                    Kindex=find(strcmp(KArray,'dot'));
                    if size(Kindex,2)>0
                        K=K+KWArray(Kindex)*(DataSet*DataSet2');
                    end
                %RBF Kernel (Radial Based Function)
                    Kindex=find(strcmp(KArray,'rbf'));
                    if size(Kindex,2)>0
                        dimensions=size(DataSet,2);
                        tempMatrix=zeros(size(DataSet,1),size(DataSet2,1),dimensions);
                        for i=1:dimensions
                          tempMatrix(:,:,i)=DataSet(:,i)*ones(1,size(DataSet2,1));
                        end
                        tempMatrix2=zeros(size(tempMatrix));
                        for i=1:dimensions
                          tempMatrix2(:,:,i)=ones(size(DataSet,1),1)*DataSet2(:,i)';
                        end
                        subsMatrix=(tempMatrix2-tempMatrix).^2;
                        addMatrix=zeros(size(DataSet,1),size(DataSet2,1));
                        for i=1:dimensions
                          addMatrix=addMatrix+subsMatrix(:,:,i);
                        end
                        addMatrix=exp(-0.5.*addMatrix./(rbf_sigma)^2);
                        K=K+(KWArray(Kindex).*addMatrix);
                    end
                %POLY2 (QUADRATIC POLYNOMIAL)
                    Kindex=find(strcmp(KArray,'poly2'));
                    if size(Kindex,2)>0
                        K=K+KWArray(Kindex)*(((DataSet*DataSet2')+poly_Const).^2);
                    end
                %POLY3 (QUADRATIC POLYNOMIAL)
                    Kindex=find(strcmp(KArray,'poly3'));
                    if size(Kindex,2)>0
                        dimensions=size(DataSet,2);
                        tempMatrix=zeros(size(DataSet,1),size(DataSet2,1),dimensions);
                        for i=1:dimensions
                          tempMatrix(:,:,i)=DataSet(:,i)*ones(1,size(DataSet2,1));
                        end
                        tempMatrix2=zeros(size(tempMatrix));
                        for i=1:dimensions
                          tempMatrix2(:,:,i)=ones(size(DataSet,1),1)*DataSet2(:,i)';
                        end
                        subsMatrix=((tempMatrix2+tempMatrix).^2)+poly_Const;
                        addMatrix=zeros(size(DataSet,1),size(DataSet2,1));
                        for i=1:dimensions
                          addMatrix=addMatrix+subsMatrix(:,:,i);
                        end
                        addMatrix=addMatrix.^3;
                        K=K+(KWArray(Kindex).*addMatrix);
                    end
                kernel=K;
end