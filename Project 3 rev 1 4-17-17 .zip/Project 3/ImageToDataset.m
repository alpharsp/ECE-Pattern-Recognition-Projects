%%THIS FUNCTION READS AN IMAGE FILE AND IT CONVERTS IT INTO A DATASET, FOR EACH 
%%PIXEL, IF THE COLOR IS 'DARK ENOUGH' IT WILL BE CONSIDERED AS A SAMPLE, IF ITS 
%%VERY LIGHT IT WILL BE CONSIDERED JUST A BLANK PIXEL (NO DATA).
function [DataSet,Labels] = ImageToDataset()
    maxRGB=700; %tresshold
    [FileName,Path]=uigetfile({'*.*'});
    imageDir=[Path,FileName];
    ImageM=imread(imageDir);
        R=double(ImageM(:,:,1));
        G=double(ImageM(:,:,2));
        B=double(ImageM(:,:,3));
        RGBSUM=R+G+B;
        IsPoint=RGBSUM<=maxRGB;
        [Datay,Datax]=find(IsPoint);
        DataSet=[Datax,Datay];
        Labels=ones(size(Datax));
end