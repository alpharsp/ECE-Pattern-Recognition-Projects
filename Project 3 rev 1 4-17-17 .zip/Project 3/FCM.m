%%FUZZY C MEANS CLUSTERING
%%RETURNS THE MEMBERSHIP MATRIX OF THE DATA SAMPLES, VECTOR V WITH THE CENTERS OF
%%ALL THE CLUSTERS, AND THE NUMBER OF ITERATIONS USED DURING THE CALCULATION.
%%INPUTS:
%%1)DataSet
%%2)totClasses: total number of clusters predicted by the user
%%3)q: fuzziness, any number greater than 1, the largest it is, the softer
%%is the membership function of each cluster.
%%4)dType: type of siatance measurement where 1 is euclidean 2 is
%%mahalanobis and 3 is Gustafson-kessel
function [MemMatrix,absolutnessMatrix,V,iterations]=FCM(DataSet,totClasses,q,dType)
maxIterations=200; %max number of iterations on the fuzzy c means
maxMovementFractionStop=100000; %if the change in V is this amount smaller 
[totSamples,Dimensions]=size(DataSet);
[minPoint,maxPoint] = minMaxCorners(DataSet);
iterations=1;
maxChange=0;
stop=false;
%Initially all the sample belong to all the clusters
absolutnessMatrix=ones(totClasses,totSamples);
while iterations<=maxIterations && not(stop)
    if iterations==1
        %Random Cluster Centers on Initialization
        V=(rand(totClasses,Dimensions).*(maxPoint-minPoint))+minPoint;
    else
        for i=1:totClasses
            numeratorVector=zeros(1,Dimensions);
            denominator=0;
            for j=1:totSamples
                numeratorVector=numeratorVector+((U(i,j)^q)*DataSet(j,:));
                denominator=denominator+(U(i,j)^q);
            end
            oldV=V;
            V(i,:)=numeratorVector/denominator;
            change=abs(sum(sum(V-oldV)));
            if change>maxChange
                maxChange=change;
            end
            if change<=maxChange/maxMovementFractionStop
                stop=true;
            end
        end
    end
    %Distance Matrix
        DM=distanceMatrix(DataSet,V,dType);
    %Membership Matrix
        U=MembershipMatrix(DM,q);
    %AbsolutnessMatrix a digital version of the membership matrix
        absolutnessMatrix=U==max(U);
    iterations=iterations+1;
end
MemMatrix=U;
end