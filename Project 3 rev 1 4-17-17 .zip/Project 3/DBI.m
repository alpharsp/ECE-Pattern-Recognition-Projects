%%DAVIES BOULDIN'S INDEX
function index= DBI(DataSet,AM,distanceType)
        totClasses=size(AM,1);
        [totSamples,Dimensions]=size(DataSet);
        %Get cluster Centers
            centers=zeros(totClasses,Dimensions);
            for i=1:totClasses
                indices=find(AM(i,:)');
                Datos=DataSet(indices,:); %Cluster Items
                center=mean(Datos); %Cluster center
                centers(i,:)=center;
            end
        indexSum=0;
        for i=1:totClasses
            indices=find(AM(i,:)');
            Datos=DataSet(indices,:); %Cluster1 Items
            center=centers(i,:);
            clusterN=size(Datos,1);
            %Average distance to cluster center
                ADTCC=sum(distanceMatrix(Datos,center,distanceType))/clusterN;
            maxOp=0;
            for j=1:totClasses
                if j~=i
                    indices=find(AM(j,:)');
                    Datos=DataSet(indices,:); %Cluster1 Items
                    center=centers(j,:);
                    clusterN=size(Datos,1);
                    %Average Distance to Other Cluster Center
                        ADTOCC=sum(distanceMatrix(Datos,center,distanceType))/clusterN;
                    op1=(ADTCC+ADTOCC)/distanceMatrix(centers(i,:),centers(j,:),distanceType);
                    if op1>maxOp
                        maxOp=op1;
                    end
                end
            end
            indexSum=indexSum+maxOp;
        end
        index=indexSum/totClasses;
end