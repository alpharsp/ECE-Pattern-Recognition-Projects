%%THIS FUNCTION CREATES A MEMBERSHIP MATRIX BASED ON A DISTANCE MATRIX AND
%%FUZZINESS VALUE. REGARDLESS OF WHAT TYPE OF DISTANCE MEASUREMENT WAS USED
%%TO CREATE THE DISTANCE MATRIX
function MM = MembershipMatrix(distanceMatrix,fuzziness)
    [totClasses,totSamples]=size(distanceMatrix);
    minDist=min(min(distanceMatrix));
    avoidZero=minDist/1000;
    MM=zeros(totClasses,totSamples);
    for i=1:totClasses
        for j=1:totSamples
            %Each element of the membershipmatrix
            denominator=0;
            for k=1:totClasses
                denominator=denominator+((distanceMatrix(i,j)/(distanceMatrix(k,j)+avoidZero))^(1/(fuzziness-1)));
            end
            MM(i,j)=1/denominator;
        end
    end
end