function orderedIndex = VAT(dissimilarMatrix)
                    R=dissimilarMatrix;
                    totSamples=size(R,1);
                    sampleIndexes=1:1:totSamples;
                    P=zeros(1,totSamples);
                    maxVal=max(max(R));
                    [maxIs,maxJs]=find(R==maxVal);
                    maxI=maxIs(1);
                    P(1)=maxI;
                    ordered=maxI;
                    remaining=sampleIndexes(1,find(1-(sampleIndexes==maxI)));
                    for k=2:totSamples
                        tempR=R(ordered,remaining);
                        minVal=min(min(tempR));
                        [minIs,minJs]=find(tempR==minVal);
                        minJs=remaining(minJs);
                        minJ=minJs(1);
                        P(k)=minJ;
                        ordered=[ordered,minJ];
                        remaining=remaining(1,find(1-(remaining==minJ)));
                    end
                    orderedIndex=P;
end