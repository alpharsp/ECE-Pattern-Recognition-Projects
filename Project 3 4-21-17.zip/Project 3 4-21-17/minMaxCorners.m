function [minPoint,maxPoint] = minMaxCorners(DataSet)
    [totSamples,Dimensions]=size(DataSet);
    minPoint=zeros(1,Dimensions);
    maxPoint=zeros(1,Dimensions);
    for i=1:Dimensions
        minPoint(1,i)=min(DataSet(:,i));
        maxPoint(1,i)=max(DataSet(:,1));
    end
end