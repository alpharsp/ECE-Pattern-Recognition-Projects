%-------------------------------------------------------------------------------
%DATASET
  %CREATE DATASETFILE BY READING AN IMAGE
    %exportImageData();
  %READ DATASET FILE
    lblCol=3; %Label is the 3rd column in the file
    c1Lbl='1'; %Uniclass all items are class '1'
    platform='octave';
    [DataSet,Labels]=readDataset(lblCol, platform, c1Lbl);
%-------------------------------------------------------------------------------
%-------------------------------------------------------------------------------
%SETTINGS
q=1.1;          %Fuzzyness cannot be 1
dType=1;        %1=>euclidean 2=>Mahalanobis 3=>Gustafson-Kessel Dusring Clustering
VDT=1;          %Euclidean Distance during Validation
C=2:9;       %Different values of C to test (Number of Clusters)
%-------------------------------------------------------------------------------
[totSamples,Dimensions]=size(DataSet);
%-------------------------------------------------------------------------------
%CALCULATE NUMBER OF CLUSTERS
indexes=zeros(3,size(C,2));
for i=1:size(C,2)
    %CLUSTERING TECHNIQUES
        %FUZZY C MEANS (FCM)
            %Algorithm
                [U,AM,V,iterations]=FCM(DataSet,C(i),q,dType);
            %KCM

            %PROBABILISTIC C MEANS (PCM)
    %CLUSTER VALIDATION
            %Davies Bouldin's index (The lower the better)
                DBIndex=DBI(DataSet,AM,VDT);
            %Partition Coeficient Index (The higher the better)
                PCIndex=sum(sum(U.^2))/totSamples;
            %Dunn's Index (The higher the better)
                DIndex=DI(DataSet,AM,VDT);
            indexes(1,i)=DBIndex;
            indexes(2,i)=PCIndex;
            indexes(3,i)=DIndex;
end
Results=zeros(3,1);
Results(1,1)=find(indexes(1,:)==min(indexes(1,:)));
Results(2,1)=find(indexes(2,:)==max(indexes(2,:)));
Results(3,1)=find(indexes(3,:)==max(indexes(3,:)));
totClusters=C(mode(Results));
%-------------------------------------------------------------------------
%FUZZY C MEANS (FCM)
    %Algorithm
        [U,AM,V,iterations]=FCM(DataSet,totClusters,q,dType);
        nType=1;
        alpha=0.1;
        %need to input the U and V from fuzzy c means into the PCM
        [U,AM,V,iterations]=PCM(DataSet,totClusters,q,nType,alpha,dType,U,V);
%--------------------------------------------------------------------------
    %CLUSTER TENDENCY ANALYSIS
            %VAT (Validation Assesment of Cluster Tendency), orders data to
            %visualize structure
                %Original Dissimilarity Matrix (Similar to a Kernel)
                    R=distanceMatrix(DataSet,DataSet,1);
                    R=round(((R./max(max(R))).*255)); %Scaled for grayscal
                %VAT ORDERING AN DISPLAY ALGORITHM
                    P=VAT(R); %order the samples need to be for proper visualization
                    orderedDataSet=DataSet(P,:);
                    orderedR=distanceMatrix(orderedDataSet,orderedDataSet,1);
                    orderedR=round(((orderedR./max(max(orderedR))).*255)); %Scaled for grayscale
                %iVAT USING PROFESSORS VAT AND iVAT ALGORITHMS
                    [RiV] = DerekiVAT(R);
%--------------------------------------------------------------------------
%--------------------------------------------------------------------------
%--------------------------------------------------------------------------
%PLOTS
  %Original DataSet
    figure;
    scatter(DataSet(:,1),DataSet(:,2),'k','fill');
    title('RAW DATA FROM DATASET');
    xlabel('IMAGE X AXIS');
    ylabel('IMAGE Y AXIS');
    axis ij;
    %on the same plot, plot the n random points
    hold;
    scatter(V(:,1),V(:,2),'b','fill');
    hold;
 %FCM Cluster Points
    figure;
    hold;
    for i=1:totClusters
        indices=find(AM(i,:)');
        Datos=DataSet(indices,:);
        scatter(Datos(:,1),Datos(:,2),'fill');
    end
    hold;
    title('FCM');
    xlabel('IMAGE X AXIS');
    ylabel('IMAGE Y AXIS');
    axis ij;
 %Original Dissimilarity Matrix
    figure;
    grayR=zeros(totSamples,totSamples,3);
    grayR(:,:,1)=R;grayR(:,:,2)=R;grayR(:,:,3)=R;
    grayR=uint8(grayR);
    image(grayR);
    title('Original Dissimilarity');
 %VAT Display
    figure;
    grayR=zeros(totSamples,totSamples,3);
    grayR(:,:,1)=orderedR;grayR(:,:,2)=orderedR;grayR(:,:,3)=orderedR;
    grayR=uint8(grayR);
    image(grayR);
    title('VAT Ordered Dissimilarity');
  %iVAT
    figure;
    grayR=zeros(totSamples,totSamples,3);
    grayR(:,:,1)=RiV;grayR(:,:,2)=RiV;grayR(:,:,3)=RiV;
    grayR=uint8(grayR);
    image(grayR);
    title('iVAT');
 %Visualize order of the samples
    figure;
    plot(orderedDataSet(:,1),orderedDataSet(:,2));
    title('Order of Samples after VAT');
%-------------------------------------------------------------------------------

