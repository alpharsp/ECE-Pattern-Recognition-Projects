%%THIS FUNCTION USES IMAGETODATASET FUNCTION TO READ AN IMAGE AND CONVERT IT 
%%INTO A SINGLE CLASS DATASET, THE IT SAVES THE DATASET AS A TXT FILE WITH THE
%%LOCATION AND NAME SPECIFIED BY THE USER SINCE IT IS A SINGLE CLASS, THE LABELS
%%WILL BE 1 FOR ALL THE ITEMS
function exportImageData()
  [DataSet,Labels]=ImageToDataset();
  [file,path]=uiputfile('.txt','Save Dataset','DataSet.txt');
  fileLocation=[path,file];
  fid=fopen(fileLocation,'w');
  fprintf(fid,'%.4f   %.4f   1\r\n',DataSet');
  fclose(fid);
end