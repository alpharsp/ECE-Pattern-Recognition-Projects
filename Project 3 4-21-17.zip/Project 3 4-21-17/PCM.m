%%POSSIBILISTIC C MEANS
%%RETURNS THE MEMBERSHIP MATRIX OF THE DATA SAMPLES, VECTOR V WITH THE CENTERS OF
%%ALL THE CLUSTERS, AND THE NUMBER OF ITERATIONS USED DURING THE CALCULATION.
%%INPUTS:
%%1)DataSet
%%2)totClasses: total number of clusters predicted by the user
%%3)q: fuzziness, any number greater than 1, the largest it is, the softer
%%is the membership function of each cluster.
%%4)nType options: 1,2. type 2 only consider those members higher than alpha for the calculation of n
%%5) alpha, is the triger membership for calculation of n, needs to be a number between 0 and 1
%%if  nType==1 then alpha is not used
%%6)dType: type of siatance measurement where 1 is euclidean 2 is
%%7)U_FCM: membership matrix as an output from fuzzy c means
%%8)V_FCM; cluster centers as calculated in the fuzzy c means
%%mahalanobis and 3 is Gustafson-kessel
function [MemMatrix,absolutnessMatrix,V,iterations]=PCM(DataSet,totClasses,q,nType,alpha,dType,U_FCM,V_FCM)
maxIterations=200; %max number of iterations on the fuzzy c means
maxMovementFractionStop=100000; %if the change in V is this amount smaller
[totSamples,Dimensions]=size(DataSet);
iterations=1;
maxChange=0;
stop=false;
%Initially we use V and U from the fuzzy c means
absolutnessMatrix=ones(totClasses,totSamples);
while iterations<=maxIterations && not(stop)
    if iterations==1
        %INITIAL ITERATION
        V=V_FCM;
        U=U_FCM;
    else
        for i=1:totClasses
            numeratorVector=zeros(1,Dimensions);
            denominator=0;
            for j=1:totSamples
                numeratorVector=numeratorVector+((U(i,j)^q)*DataSet(j,:));
                denominator=denominator+(U(i,j)^q);
            end
            oldV=V;
            V(i,:)=numeratorVector/denominator;
            change=abs(sum(sum(V-oldV)));
            if change>maxChange
                maxChange=change;
            end
            if change<=maxChange/maxMovementFractionStop
                stop=true;
            end
        end
     end
       %THIS REPEATES ON EVERY ITERATION
        %Distance Matrix
            DM=distanceMatrix(DataSet,V,dType);
       %Calculation of possibilistic penalty n
          n=zeros(totClasses,1);
          for i=1:totClasses
              %n calc merhod 1
              if nType==1
                  n(i)=((U(i,:).^q)*DM(i,:)')/sum((U(i,:).^q));
              end
              %n cal method 2
              if nType==2
                  accountable=(U>=alpha);
                  n(i)=sum(accountable(i,:).*DM(i,:))/(sum(accountable(i,:))+0.0000001);
              end
          end
        %Membership Matrix
            U=MembershipMatrixPCM(DM,n,q);
        %AbsolutnessMatrix a digital version of the membership matrix
            absolutnessMatrix=U==max(U);
        iterations=iterations+1;
end
MemMatrix=U;
end