%% THIS FUNCTION GENERATES THE DISTANCE MATRIX, WHICH IS AN ARRAY WITH ALL
%%THE DISTANCES BETWEEN A SET OF SAMPLES AND A SET OF CLUSTER CENTERS. EVERY
%%ITEM IS THE DISTANCE BETWEEN 1 SAMPLE AND 1 CLUSTER CENTER, EACH COLUMN
%%REPRESENT THE SAMPLE NUMBER AND EACH ROW REPRESENT THE CLUSTER_CENTER
%%NUMBER.
%%DISTANCE TYPE OPTIONS:
%%1  WHICH CORRESPONDS TO EUCLIDEAN DISTANCE
%%2 WHICH CORRESPONDS TO MAHALANOBIS DISTANCE
%%3 WHICH CORRESPONDS TO GUSTAFSON-KESSEL 
function DM=distanceMatrix(DataSet,Centers,distanceType)
    totClasses=size(Centers,1);
    [totSamples,Dimensions]=size(DataSet);
    DM=zeros(totClasses,totSamples);
    %Additional Elements

    %Compute Distances
    for i=1:totClasses
        ccenter=Centers(i,:);
        %Covariance Matrix
            CM=zeros(Dimensions);
            for j=1:totSamples
                CM=CM+((DataSet(j,:)-ccenter)'*(DataSet(j,:)-ccenter));
            end
        for j=1:totSamples
            sample=DataSet(j,:);
            %Euclidean Distance
            if distanceType==1
                DM(i,j)=sqrt((ccenter-sample)*(ccenter-sample)');
            end
            %Mahalanobis Distance
            if distanceType==2
                DM(i,j)=sqrt((ccenter-sample)*inv(CM)*(ccenter-sample)');
            end
            %Gustaffson Kessel Distance
            if distanceType==3
                DM(i,j)=sqrt((det(CM)^(1/Dimensions))*(ccenter-sample)*inv(CM)*(ccenter-sample)');
            end
        end
    end
end