%%THIS FUNCTION CREATES A MEMBERSHIP MATRIX BASED ON A DISTANCE MATRIX AND
%%FUZZINESS VALUE. REGARDLESS OF WHAT TYPE OF DISTANCE MEASUREMENT WAS USED
%%TO CREATE THE DISTANCE MATRIX
function MM = MembershipMatrixPCM(distanceMatrix,n,fuzziness)
    [totClasses,totSamples]=size(distanceMatrix);
    MM=zeros(totClasses,totSamples);
    n=n+0.000001; %avoid 0 division
    for i=1:totClasses
        for j=1:totSamples
            MM(i,j)=1/(1+((distanceMatrix(i,j)/n(i))^(1/(fuzziness-1))));
        end
    end
end