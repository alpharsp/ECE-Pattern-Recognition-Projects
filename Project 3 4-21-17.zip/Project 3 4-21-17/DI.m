function index = DI(DataSet,AM,VDT)
            totClasses=size(AM,1);
            [totSamples,Dimensions]=size(DataSet);
            %Obtain max distance between internal components of all
            %clusters, the select the max among all clusters
                maxD=0;
                for i=1:totClasses
                    indices=find(AM(i,:)');
                    Datos=DataSet(indices,:); %Cluster Items
                    maxD1=max(max(distanceMatrix(Datos,Datos,VDT)));
                    if maxD1>maxD
                        maxD=maxD1;
                    end
                end
            for i=1:totClasses
                indices=find(AM(i,:)');
                Datos1=DataSet(indices,:);
                for j=1:totClasses
                    if i~=j
                        indices=find(AM(j,:)');
                        Datos2=DataSet(indices,:);
                        %Min distance between items of 2 different clusters
                        minDist=min(min(distanceMatrix(Datos1,Datos2,VDT)));
                        op1=minDist/maxD;
                        if i==1 && j==2
                            minOp=op1;
                        else
                            if op1<minOp
                                minOp=op1;
                            end
                        end
                    end
                end
            end
            index=minOp;
end